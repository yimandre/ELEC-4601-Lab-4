/*-------------------------------
LAB EXERCISE 4 - INTERRUPT IN/OUT
PROGRAMMING USING MBED API
 --------------------------------*/

#include "mbed.h"

//Define your outputs
//Write your code here


//Define your interrupt inputs
//Write your code here


//Define ISRs for the interrupts
//If the switch is high, so should the LED
//If the switch is low, so should the LED
//Remember, the LED will turn on when we give it a '0'
void button_1_handler(){
	//Write your code here
	
}

void button_2_handler(){
	//Write your code here
	
}

void button_3_handler(){
	//Write your code here
	
}

void button_4_handler(){
	//Write your code here
	
}

/*----------------------------------------------------------------------------
 MAIN function
 *----------------------------------------------------------------------------*/

int main(){
	//Enable interrupts
	//Think about which header file has this method
	//Write your code here
	
	
	//Initially turn off all LEDs
	//Remember, the LED will turn on when we give it a '0'
	//Write your code here
	
	
	//Attach the handler to the rising edge of the interrupt
	//Think about which header file has this method
	//Write your code here
	
	
	//Attach the handler to the falling edge of the interrupt
	//Think about which header file has this method
	//Write your code here
	
	
	//Sleep on exit
	while(1){
		//__wfi();
		//Leave this line of code commented out for now
	}
}

// *******************************ARM University Program Copyright (c) ARM Ltd 2014*************************************
