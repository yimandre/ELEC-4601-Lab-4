/*----------------------------
LAB EXERCISE 4 - TIMER AND PWM
 -----------------------------*/

#include "mbed.h"

//Define the musical notes (the frequencies of sound)
# define Do     0.5
# define Re     0.45
# define Mi     0.4
# define Fa     0.36
# define So     0.33
# define La     0.31
# define Si     0.3
# define No     0

//Define the beat lengths (e.g., whole note and half note)
# define b1     0.5
# define b2     0.25
# define b3     0.125
# define b4     0.075

//Define the musical array
float note[] = {Mi,No,Mi,No,Mi,No, Mi,No,Mi,No,Mi,No, Mi,No,So,No,Do,No,Re,No,Mi,No, Fa,No,Fa,No,Fa,No,Fa,No, Fa,No,Mi,No,Mi,No,Mi,No,Mi,No, Mi,Re,No,Re,Mi, Re,No,So,No};
float beat[] = {b3,b3,b3,b3,b2,b2, b3,b3,b3,b3,b2,b2, b3,b3,b3,b3,b3,b3,b3,b3,b2,b1, b3,b3,b3,b3,b3,b3,b3,b3, b3,b3,b3,b3,b3,b3,b4,b4,b4,b4, b2,b3,b3,b2,b2, b2,b2,b2,b2};

//Define your RGB LED
//Write your code here


//Define your speaker
//Write your code here


//Define your 2 potentiometers
//Write your code here


//Static index variable
//Hint: you will need this in the ISR
static int k;

//Define your 'Ticker'
//Write your code here


/*----------------------------------------------------------------------------
 Interrupt Service Routine
 *----------------------------------------------------------------------------*/

void timer_ISR(){ 
	/*
	The time Ticker ISR will be periodically triggered
	On every trigger, update the following:
		+ Update the PWM period of the speaker to play the next audio note
		+ Update the beat length of your interrupt source
		+ Update the colour of the RGB LED to reflect the melody changing (however you'd like)
		+ The inputs from the two potentiometers will be used to adjust the volume and the speed
		+ Switch to the next note in the musical array
	*/
	//Write your code here
	
} 

/*----------------------------------------------------------------------------
 MAIN function
 *----------------------------------------------------------------------------*/

int main(){
	//Initialize the 'Ticker'
	//Write your code here

	//Sleep on exit
	while(1){
		//__wfi();
		//Leave this line of code commented out for now
	}
}

// *******************************ARM University Program Copyright (c) ARM Ltd 2014*************************************
